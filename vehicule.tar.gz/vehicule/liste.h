#ifndef LISTE_H
#define LISTE_H

#include"vehicules.h"
#include"reservation.h"
#include"client.h"

typedef enum typeListe{
	VEHICULE, RESERVATION, CLIENT
}typeListe;

union datas{
	vehicules vehicule;
	reservations reservation;
	clients client;
};

typedef struct liste{
	int type;
	union datas data;
	struct liste *suivant;
}liste;

liste* lireListe(int i);
void afficheListe(liste* lliste);
void lireListeT(void);
vehicules* detectVoiture(liste* tete, char immat[10]);
clients* detectClient(liste* tete, long int num);

#endif

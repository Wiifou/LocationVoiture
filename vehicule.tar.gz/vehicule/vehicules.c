#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"vehicules.h"
#include"liste.h"

liste* getListeVehicule(FILE* file, liste* tete)
{

	liste* maillon = NULL;
	maillon = malloc(sizeof(*maillon));
	fscanf(file, "%s;",maillon->data.vehicule.immat);
	fgetc(file);
	fgetc(file);
	fscanf(file, "%s;",maillon->data.vehicule.marque);
	fgetc(file);
	fgetc(file);
	fscanf(file, "%s;",maillon->data.vehicule.modele);
	fgetc(file);
	fgetc(file);
	fscanf(file, "%hd;",&maillon->data.vehicule.millesime);
	fscanf(file, "%d;",&maillon->data.vehicule.kilometrage);
	fscanf(file, "%c",&maillon->data.vehicule.categorie);
	maillon->suivant = tete;
	maillon->type = VEHICULE;
	return maillon;
}

liste* getListeReservation(FILE* file, liste* tete)
{
	liste* maillon = NULL;
	maillon = malloc(sizeof(*maillon));
	fscanf(file, "%d;",&maillon->data.reservation.num_reserv);
	fscanf(file, "%d/",&maillon->data.reservation.date_debut[1]);
	fscanf(file, "%d/",&maillon->data.reservation.date_debut[2]);
	fscanf(file, "%d;",&maillon->data.reservation.date_debut[3]);
	fscanf(file, "%d/",&maillon->data.reservation.date_fin[1]);
	fscanf(file, "%d/",&maillon->data.reservation.date_fin[2]);
	fscanf(file, "%d;",&maillon->data.reservation.date_fin[3]);
	fscanf(file, "%ld;",&maillon->data.reservation.num_permis);
	fscanf(file, "%s;",maillon->data.reservation.immat);
	maillon->data.reservation.veve = detectVoiture(lireListe(VEHICULE), maillon->data.reservation.immat);
	maillon->data.reservation.client = detectClient(lireListe(CLIENT), maillon->data.reservation.num_permis);
	maillon->suivant = tete;
	maillon->type = RESERVATION;
	return maillon;
}
liste* getListeClient(FILE* file, liste* tete)
{
	liste* maillon = NULL;
	maillon = malloc(sizeof(*maillon));
	fscanf(file, "%ld;",&maillon->data.client.num_permis);
	fscanf(file, "%d/",&maillon->data.client.date_naissance[0]);
	fscanf(file, "%d/",&maillon->data.client.date_naissance[1]);
	fscanf(file, "%d;",&maillon->data.client.date_naissance[2]);
	fscanf(file, "%d/",&maillon->data.client.date_permis[0]);
	fscanf(file, "%d/",&maillon->data.client.date_permis[1]);
	fscanf(file, "%d;",&maillon->data.client.date_permis[2]);
	fscanf(file, "%s;",maillon->data.client.prenom);
	fgetc(file);
	fgetc(file);
	fscanf(file, "%s;",maillon->data.client.nom);
	maillon->suivant = tete;
	maillon->type = CLIENT;
	return maillon;
}

liste* lireListe(int i)
{
	int ii;
	FILE* file;
	liste* tete = NULL;
	liste* (*ptrFonction)(FILE*,liste*);
	if(i == VEHICULE)
	{
		file = fopen("vehicules.csv", "rt");
		fscanf(file,"%d;marque;modele;millesime;kilometrage;categorie", &ii);
		ptrFonction = getListeVehicule;

	}
	else if(i == RESERVATION)
	{
		file = fopen("reservations.csv", "rt");
		fscanf(file,"%d;num_reservation;date_debut;date_fin;num_permis;immatriculation", &ii);
		ptrFonction = getListeReservation;
	}
	else if(i == CLIENT)
	{
		file = fopen("client.csv", "rt");
		fscanf(file,"%d;num_permis;date_naissance;date_permis;prenom;nom", &ii);
		ptrFonction = getListeClient;
	}
	int iii;
	for(iii = 0; iii < ii; iii++)
	{
		tete = (*ptrFonction)(file,tete);
	}
	fclose(file);
	return tete;
}
void lireListeT(void)
{
	FILE* file = fopen("client.csv", "rt");
	int ii, i;
	int date_n[3],date_p[3];
	long int num;
	char prenom[15], nom[30];
	fscanf(file,"%d;num_permis;date_naissance;date_permis;prenom;nom", &ii);
	for(i = 0; i < ii; i++)
	{
		fscanf(file, "%ld;",&num);
		fscanf(file, "%d/",&date_n[1]);
		fscanf(file, "%d/",&date_n[2]);
		fscanf(file, "%d;",&date_n[3]);
		fscanf(file, "%d/",&date_p[1]);
		fscanf(file, "%d/",&date_p[2]);
		fscanf(file, "%d;",&date_p[3]);
		fscanf(file, "%s;",prenom);
		fgetc(file);
		fgetc(file);
		fscanf(file, "%s;",nom);
		printf("%ld;%d/%d/%d;%d/%d/%d;%s;%s\n", num, date_n[1], date_n[2], date_n[3], date_p[1], date_p[2], date_p[3], prenom, nom);
	}
	fclose(file);
}
vehicules* detectVoiture(liste* tete, char immat[10])
{
	liste *maillon = tete;
	while(!strcmp(maillon->data.vehicule.immat, immat) && maillon != NULL)
		maillon = maillon->suivant;
	vehicules* veve = &(maillon)->data.vehicule;
	return veve;
}
clients* detectClient(liste* tete, long int num)
{
	liste* maillon = tete;
	while(num != maillon->data.client.num_permis  && maillon != NULL)
		maillon = maillon->suivant;
	clients* clicli = &(maillon)->data.client;
	return clicli;
}
void afficheListe(liste* tete)
{
	liste* maillon = tete;
	if(maillon->type == VEHICULE)
		while(maillon != NULL)
		{
			printf("%s;%s;%s;%hd;%d;%c\n",maillon->data.vehicule.immat,maillon->data.vehicule.marque,maillon->data.vehicule.modele,maillon->data.vehicule.millesime,maillon->data.vehicule.kilometrage,maillon->data.vehicule.categorie);
		maillon = maillon->suivant;
		}
	else if(maillon->type == RESERVATION)
		while(maillon != NULL)
		{
			printf("%d;%d/%d/%d;%d/%d/%d;%ld;%s\n",maillon->data.reservation.num_reserv,maillon->data.reservation.date_debut[0],maillon->data.reservation.date_debut[1],maillon->data.reservation.date_debut[2],maillon->data.reservation.date_fin[0],maillon->data.reservation.date_fin[1],maillon->data.reservation.date_fin[2],maillon->data.reservation.num_permis,maillon->data.reservation.immat);
		printf("%s;%s;%s;%hd;%d;%c\n",maillon->data.reservation.veve->immat,maillon->data.reservation.veve->marque,maillon->data.reservation.veve->modele,maillon->data.reservation.veve->millesime,maillon->data.reservation.veve->kilometrage,maillon->data.reservation.veve->categorie);
		printf("%ld;%d/%d/%d;%d/%d/%d;%s;%s\n", maillon->data.reservation.client->num_permis, maillon->data.reservation.client->date_naissance[0], maillon->data.reservation.client->date_naissance[1], maillon->data.reservation.client->date_naissance[2], maillon->data.reservation.client->date_permis[0], maillon->data.reservation.client->date_permis[1], maillon->data.reservation.client->date_permis[2], maillon->data.reservation.client->prenom, maillon->data.reservation.client->nom);
		printf("\n");
		maillon = maillon->suivant;
		}
	else if(maillon->type == CLIENT)
	while(maillon != NULL)
		{
			printf("%ld;%d/%d/%d;%d/%d/%d;%s;%s\n", maillon->data.client.num_permis, maillon->data.client.date_naissance[0], maillon->data.client.date_naissance[1], maillon->data.client.date_naissance[2], maillon->data.client.date_permis[0], maillon->data.client.date_permis[1], maillon->data.client.date_permis[2], maillon->data.client.prenom, maillon->data.client.nom);
		maillon = maillon->suivant;
		}
}


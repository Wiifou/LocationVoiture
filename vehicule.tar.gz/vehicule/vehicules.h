#ifndef VEHICULES_H
#define VEHICULES_H

/*typedef enum marques{
	Alfa_Romeo, Alpine, Aston_Martin, Audi, Austin, Bentley, BMW, Bugatti, Cadillac, Chevrollet, Chrysler, Citroen, Dacia, Dodge, Ferrari, Ford, Ford_Mustang, Honda, Hyundai, Isuzu, Iveco, Jaguar, Jeep, Kia, Lamborghini, Lancia, Land_Rover, Lexus, Lotus, Maserati, Mazda, Mega, Mercedes_Benz, McLaren, Mia, Mini, Morgan, Nissan, Opel, Pagani, Peugeot, Plymouth, Pontiac, Porsche, Renault, Riley, Rolls_Royce, Rover, Saab, Skoda, Smart, Subaru, Suzuki, Tesla_Motors, Toyota, Volkswagen, Volvo
}marques;*/
typedef struct vehicules{
	char immat[10];
	char marque[15];
	char modele[15];
	short int millesime;
	int kilometrage;
	char categorie;
}vehicules;

#endif

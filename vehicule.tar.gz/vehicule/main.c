#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"vehicules.h"
#include"liste.h"



int main(void)
{
	/*lireListeT();
	printf("\n\n");*/
	afficheListe(lireListe(RESERVATION));
	printf("\n\n");
	afficheListe(lireListe(VEHICULE));
	printf("\n\n");
	afficheListe(lireListe(CLIENT));

	return 0;
}
